package DAO;

import Model.Cliente;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ClienteDAOTest {

    @Test
    public void deveSalvarCliente() {

        Cliente cliente = new Cliente();

        cliente.setNome("João da Silva");
        cliente.setCpfCnpj(String.valueOf(System.currentTimeMillis()));
        cliente.setTelefone("34999999999");
        cliente.setEmail("joao@email.com");
        cliente.setEndereco("Rua A, 123");

        ClienteDAO dao = new ClienteDAO();

        cliente = dao.salvar(cliente);
        
        assertTrue(cliente.getId() > 0);
    }
}