package FactoryContrato.clausulas;

import FactoryContrato.Clausula;
import Model.Orcamento;

public class ClausulaLED implements Clausula{
    @Override
    public String gerar(Orcamento o) {
        return """
        CLÁUSULA - PAINEL DE LED

        A LOCATÁRIA deverá fornecer:
        - Estrutura adequada para fixação dos painéis
        - Proteção contra vento, chuva e calor
        - Energia estabilizada

        Danos por mau uso ou condições climáticas são responsabilidade da LOCATÁRIA.
               
        """;
    }
}
