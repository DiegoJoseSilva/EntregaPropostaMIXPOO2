package FactoryContrato.clausulas;

import FactoryContrato.Clausula;
import Model.Orcamento;


public class ClausulaIluminacao implements Clausula{
    @Override
    public String gerar(Orcamento o) {
        return """
        ILUMINAÇÃO:

        - Rede elétrica exclusiva recomendada
        - Proteção contra sobrecarga
        - Estabilidade de energia obrigatória
               
        """;
    }
}
