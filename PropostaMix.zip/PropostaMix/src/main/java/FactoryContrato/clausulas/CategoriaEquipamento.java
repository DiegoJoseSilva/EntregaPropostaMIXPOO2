package FactoryContrato.clausulas;

public enum CategoriaEquipamento {
    AUDIO,
    ILUMINACAO,
    LED,
    ESTRUTURA,
    GERADOR,
    OUTROS;

    public static CategoriaEquipamento fromString(String categoria) {

        if (categoria == null || categoria.isBlank()) {
            return OUTROS;
        }

        try {
            return CategoriaEquipamento.valueOf(categoria.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return OUTROS;
        }
    }
}
