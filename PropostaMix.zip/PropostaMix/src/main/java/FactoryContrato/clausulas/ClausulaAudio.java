package FactoryContrato.clausulas;

import FactoryContrato.Clausula;
import Model.Orcamento;


public class ClausulaAudio implements Clausula {
    @Override
    public String gerar(Orcamento o) {
        return """
        SISTEMA DE ÁUDIO:

        - Energia estável obrigatória (110V/220V)
        - Aterramento adequado
        - Operação sob responsabilidade do contratante local
               
        """;
    }
}
