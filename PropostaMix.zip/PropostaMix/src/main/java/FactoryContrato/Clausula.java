package FactoryContrato;

import Model.Orcamento;

public interface Clausula {
     String gerar(Orcamento o);
}
