package FactoryContrato;

import FactoryContrato.clausulas.ClausulaLED;
import FactoryContrato.clausulas.ClausulaIluminacao;
import Model.ItemOrcamento;
import Model.Orcamento;
import FactoryContrato.clausulas.ClausulaAudio;
import FactoryContrato.clausulas.ClausulaEstrutura;
import FactoryContrato.clausulas.CategoriaEquipamento;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClausulaFactory {
    
    public static List<Clausula> criar(Orcamento orcamento) {

        Set<CategoriaEquipamento> categorias = new HashSet<>();

        for (ItemOrcamento itemOrcamento : orcamento.getItens()) {

            if (itemOrcamento.getItem() == null) continue;

            categorias.add(
                CategoriaEquipamento.fromString(itemOrcamento.getItem().getCategoria()
                )
            );
        }

        List<Clausula> clausulas = new ArrayList<>();

        if (categorias.contains(CategoriaEquipamento.AUDIO)) {
            clausulas.add(new ClausulaAudio());
        }

        if (categorias.contains(CategoriaEquipamento.ILUMINACAO)) {
            clausulas.add(new ClausulaIluminacao());
        }

        if (categorias.contains(CategoriaEquipamento.LED)) {
            clausulas.add(new ClausulaLED());
        }

        if (categorias.contains(CategoriaEquipamento.ESTRUTURA)) {
            clausulas.add(new ClausulaEstrutura());
        }

        return clausulas;
    }
    
}
