package DAO;

import Model.FluxoCaixa;
import Model.TipoMovimentacao;
import Util.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FluxoCaixaDAO {
    
    Connection conn;
    
    public FluxoCaixaDAO() {
            conn = new Conexao().conectar();
    }
    
    public boolean existeLancamentoPorOrcamento(int idOrcamento) {

        String sql = """
            SELECT COUNT(*)
            FROM fluxo_caixa
            WHERE orcamento_id = ?
        """;

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idOrcamento);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            throw new RuntimeException(
                "Erro ao verificar lançamento do orçamento.",
                e
            );
        }

        return false;
    }
    
    public FluxoCaixa salvar(FluxoCaixa fluxo) {

            String sql = """
                INSERT INTO fluxo_caixa
                (
                    orcamento_id,
                    data_lancamento,
                    descricao,
                    valor,
                    tipo
                )
                VALUES (?, ?, ?, ?, ?)
                RETURNING id
            """;

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setInt(1, fluxo.getOrcamentoId());
                stmt.setDate(2, Date.valueOf(fluxo.getDataLancamento()));
                stmt.setString(3, fluxo.getDescricao());
                stmt.setDouble(4, fluxo.getValor());
                stmt.setString(5, fluxo.getTipo().name());

                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    fluxo.setId(rs.getInt("id"));
                }

                return fluxo;

            } catch (SQLException e) {
                throw new RuntimeException(
                    "Erro ao salvar lançamento financeiro.",
                    e
                );
            }
    }
    
    public void registrarEntrada(int orcamentoId, double valor) {
        
        String sql = """
            INSERT INTO fluxo_caixa (orcamento_id, valor, tipo, data_lancamento)
            VALUES (?, ?, 'RECEITA', NOW())
        """;

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orcamentoId);
            stmt.setDouble(2, valor);

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public List<FluxoCaixa> listarTodos() {
        String sql =
            "SELECT " +
            "    fc.id, " +
                " fc.orcamento_id,"+
            "    fc.valor, " +
            "    fc.tipo, " +
            "    fc.data_lancamento, " +
            "    e.nome AS nome_evento, " +
            "    c.nome AS nome_cliente " +
            "FROM fluxo_caixa fc " +
            "INNER JOIN orcamento o ON fc.orcamento_id = o.id " +
            "INNER JOIN evento e ON o.evento_id = e.id " +
            "INNER JOIN cliente c ON o.cliente_id = c.id " +
            "ORDER BY fc.data_lancamento";

        List<FluxoCaixa> lista = new ArrayList<>();

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public List<FluxoCaixa> filtrarPorPeriodo(LocalDate inicio, LocalDate fim) {

        String sql = "SELECT\n" +
                    "    fc.id,\n" +
                    " fc.orcamento_id," +
                    "    fc.valor,\n" +
                    "    fc.tipo,\n" +
                    "    fc.data_lancamento,\n" +
                    "\n" +
                    "    e.nome AS nome_evento,\n" +
                    "    c.nome AS nome_cliente\n" +
                    "\n" +
                    "FROM fluxo_caixa fc\n" +
                    "\n" +
                    "INNER JOIN orcamento o\n" +
                    "    ON fc.orcamento_id = o.id\n" +
                    "\n" +
                    "INNER JOIN evento e\n" +
                    "    ON o.evento_id = e.id\n" +
                    "\n" +
                    "INNER JOIN cliente c\n" +
                    "    ON o.cliente_id = c.id\n" +
                    "\n" +
                    "WHERE fc.data_lancamento BETWEEN ? AND ?\n" +
                    "\n" +
                    "ORDER BY fc.data_lancamento;";

        List<FluxoCaixa> lista = new ArrayList<>();

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDate(1, Date.valueOf(inicio));
            stmt.setDate(2, Date.valueOf(fim));

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    // =========================
    // DELETE
    // =========================
    public boolean excluir(int id) {

            String sql = "DELETE FROM fluxo_caixa WHERE id = ?";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setInt(1, id);

                return stmt.executeUpdate() > 0;

            } catch (SQLException e) {
                e.printStackTrace();
            }

            return false;
    }

    // =========================
    // TOTAL ENTRADAS
    // =========================
    public double totalEntradas(LocalDate inicio, LocalDate fim) {

        String sql = "SELECT COALESCE(SUM(valor),0) FROM fluxo_caixa " +
                     "WHERE tipo = 'RECEITA' AND data_lancamento BETWEEN ? AND ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDate(1, Date.valueOf(inicio));
            stmt.setDate(2, Date.valueOf(fim));

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    // =========================
    // TOTAL SAÍDAS
    // =========================
    public double totalSaidas(LocalDate inicio, LocalDate fim) {

        String sql = "SELECT COALESCE(SUM(valor),0) FROM fluxo_caixa " +
                     "WHERE tipo = 'DESPESA' AND data_lancamento BETWEEN ? AND ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDate(1, Date.valueOf(inicio));
            stmt.setDate(2, Date.valueOf(fim));

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    // =========================
    // MAPPER (EVITA REPETIÇÃO)
    // =========================
    private FluxoCaixa mapear(ResultSet rs) throws SQLException {

        FluxoCaixa f = new FluxoCaixa();

        f.setId(rs.getInt("id"));

        Date date = rs.getDate("data_lancamento");
        if (date != null) {
            f.setDataLancamento(date.toLocalDate());
        }
        
        f.setValor(rs.getDouble("valor"));

        String tipo = rs.getString("tipo");
        if (tipo != null) {
            f.setTipo(TipoMovimentacao.valueOf(tipo));
        }
        f.setNomeEvento(rs.getString("nome_evento"));
        f.setNomeCliente(rs.getString("nome_cliente"));
        f.setOrcamentoId(rs.getInt("orcamento_id"));

        return f;
    }
}
