package DAO;

import Model.Cliente;
import Model.Evento;
import Model.ItemOrcamento;
import Model.Orcamento;
import Model.StatusPagamento;
import Util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class OrcamentoDAO {
    
    
    Connection conn;
    
    
    public OrcamentoDAO(){
        conn = new Conexao().conectar();
    }
    
    
    public Orcamento salvar(Orcamento orcamento) {

        String sqlOrcamento = """
            INSERT INTO orcamento
            (cliente_id, evento_id, data_criacao, subtotal, desconto,
             valor_total, forma_pagamento, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;

        String sqlItem = """
            INSERT INTO item_orcamento
            (orcamento_id, item_id, quantidade, valor_unitario, subtotal)
            VALUES (?, ?, ?, ?, ?)
        """;

        try {

            conn.setAutoCommit(false);

            // Salva o orçamento
            PreparedStatement stmt = conn.prepareStatement(
                    sqlOrcamento,
                    Statement.RETURN_GENERATED_KEYS);

            stmt.setInt(1, orcamento.getCliente().getId());
            stmt.setInt(2, orcamento.getEvento().getId());
            stmt.setTimestamp(3, Timestamp.valueOf(orcamento.getDataCriacao()));
            stmt.setDouble(4, orcamento.getSubtotal());
            stmt.setDouble(5, orcamento.getDesconto());
            stmt.setDouble(6, orcamento.getValorTotal());
            stmt.setString(7, orcamento.getFormaPagamento());
            stmt.setString(8, orcamento.getStatus().name());

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();

            if (!rs.next()) {
                throw new SQLException("Não foi possível obter o ID do orçamento.");
            }

            int idOrcamento = rs.getInt(1);
            orcamento.setId(idOrcamento);

            // Salva os itens
            if (orcamento.getItens() != null) {

                PreparedStatement stmtItem = conn.prepareStatement(sqlItem);

                for (ItemOrcamento item : orcamento.getItens()) {

                    double subtotal = item.getQuantidade() * item.getValorUnitario();

                    stmtItem.setInt(1, idOrcamento);
                    stmtItem.setInt(2, item.getItem().getId());
                    stmtItem.setInt(3, item.getQuantidade());
                    stmtItem.setDouble(4, item.getValorUnitario());
                    stmtItem.setDouble(5, subtotal);

                    stmtItem.executeUpdate();
                }
            }

            conn.commit();

        } catch (SQLException ex) {

            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            ex.printStackTrace();

        } finally {

            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

        return orcamento;
    }
    
    
    public boolean cancelar(int id) {

        String sql = "UPDATE orcamento SET status = 'CANCELADO' WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    
    public boolean atualizar(Orcamento orcamento) {
        
        String sqlOrcamento = """
            UPDATE orcamento
            SET cliente_id = ?,
                evento_id = ?,
                subtotal = ?,
                desconto = ?,
                valor_total = ?,
                forma_pagamento = ?
            WHERE id = ?
        """;

        String sqlDeleteItens = """
            DELETE FROM item_orcamento
            WHERE orcamento_id = ?
        """;

        String sqlItem = """
            INSERT INTO item_orcamento
            (orcamento_id, item_id, quantidade, valor_unitario, subtotal)
            VALUES (?, ?, ?, ?, ?)
        """;

        try {

            conn.setAutoCommit(false);

            // 1. UPDATE ORCAMENTO
            PreparedStatement stmt = conn.prepareStatement(sqlOrcamento);

            stmt.setInt(1, orcamento.getCliente().getId());
            stmt.setInt(2, orcamento.getEvento().getId());
            stmt.setDouble(3, orcamento.getSubtotal());
            stmt.setDouble(4, orcamento.getDesconto());
            stmt.setDouble(5, orcamento.getValorTotal());
            stmt.setString(6, orcamento.getFormaPagamento());
            stmt.setInt(7, orcamento.getId());
            
            int linhas = stmt.executeUpdate();
            System.out.println("LINHAS AFETADAS: " + linhas);
           
            // 2. DELETE ITENS ANTIGOS
            PreparedStatement stmtDelete = conn.prepareStatement(sqlDeleteItens);
            stmtDelete.setInt(1, orcamento.getId());
            stmtDelete.executeUpdate();

            // 3. INSERT NOVOS ITENS
            if (orcamento.getItens() != null) {

                PreparedStatement stmtItem = conn.prepareStatement(sqlItem);

                for (ItemOrcamento item : orcamento.getItens()) {

                    double subtotal = item.getQuantidade() * item.getValorUnitario();

                    stmtItem.setInt(1, orcamento.getId());
                    stmtItem.setInt(2, item.getItem().getId());
                    stmtItem.setInt(3, item.getQuantidade());
                    stmtItem.setDouble(4, item.getValorUnitario());
                    stmtItem.setDouble(5, subtotal);

                    stmtItem.addBatch();
                }

                stmtItem.executeBatch();
            }

            conn.commit();
            return true;

        } catch (SQLException ex) {

            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            ex.printStackTrace();
            return false;

        } finally {

            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    
    public boolean excluir(int id) {

        try {

            PreparedStatement stmt =
                    conn.prepareStatement(
                            """
                            DELETE FROM orcamento
                            WHERE id = ?
                            """
                    );

            stmt.setInt(1, id);

            stmt.executeUpdate();

            return true;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public List<Orcamento> listarTodos() {

        List<Orcamento> lista = new ArrayList<>();

        try {

            PreparedStatement stmt = conn.prepareStatement(
                            """
                            SELECT o.*,
                                   c.nome AS nome_cliente,
                                   e.nome AS nome_evento
                            FROM orcamento o
                            INNER JOIN cliente c
                                ON c.id = o.cliente_id
                            INNER JOIN evento e
                                ON e.id = o.evento_id
                            ORDER BY o.id
                            """
                    );

            ResultSet rs =
                    stmt.executeQuery();

            while (rs.next()) {

                lista.add(getOrcamento(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return lista;
    }
    
    
    public List<Orcamento> listarPorCliente(int idCliente) {
    
        List<Orcamento> orcamentos = new ArrayList<>();
        

        try {
            
            PreparedStatement stmt = conn.prepareStatement("""
                SELECT o.*, e.nome AS nome_evento, e.id AS id_evento
                FROM orcamento o
                INNER JOIN evento e ON o.evento_id = e.id
                WHERE o.cliente_id = ?
                ORDER BY o.data_criacao DESC
            """);

            stmt.setInt(1, idCliente);

            ResultSet rs = stmt.executeQuery();
            EventoDAO eventoDAO = new EventoDAO();
            ItemOrcamentoDAO itemOrcamentoDAO = new ItemOrcamentoDAO();
            
            while (rs.next()) {

                Orcamento orcamento = new Orcamento();

                orcamento.setId(rs.getInt("id"));
                orcamento.setSubtotal(rs.getDouble("subtotal"));
                orcamento.setDesconto(rs.getDouble("desconto"));
                orcamento.setValorTotal(rs.getDouble("valor_total"));
                orcamento.setFormaPagamento(rs.getString("forma_pagamento"));
                
                String statusStr = rs.getString("status");

                if (statusStr != null) {
                    orcamento.setStatus(StatusPagamento.valueOf(statusStr));
                } else {
                    orcamento.setStatus(StatusPagamento.PENDENTE);
                }
                
                orcamento.setItens(itemOrcamentoDAO.listarPorOrcamento(orcamento.getId()));

                Evento evento = eventoDAO.buscarPorId(rs.getInt("id_evento"));
                orcamento.setEvento(evento);

                Cliente cliente = new Cliente();
                cliente.setId(idCliente);
                orcamento.setCliente(cliente);

                orcamentos.add(orcamento);
            }

        } catch (SQLException e) {
                e.printStackTrace();
        }
        return orcamentos;
    }
    
    
    public Orcamento buscarPorId(int id) {

        Orcamento orcamento = null;
       
        try {

            PreparedStatement stmt = conn.prepareStatement("""
                    SELECT
                        o.*,

                        c.nome AS nome_cliente,
                        c.cpf_cnpj,
                        c.endereco,

                        e.nome AS nome_evento,
                        e.local_evento

                    FROM orcamento o

                    INNER JOIN cliente c
                        ON c.id = o.cliente_id

                    INNER JOIN evento e
                        ON e.id = o.evento_id

                    WHERE o.id = ?
                """);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                orcamento = getOrcamento(rs);

                int idOrcamento = rs.getInt("id");

                ItemOrcamentoDAO itemDAO = new ItemOrcamentoDAO();
                orcamento.setItens(itemDAO.listarPorOrcamento(idOrcamento));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return orcamento;
    }
    
    public Orcamento buscarParaContrato(int id) {

        Orcamento orcamento = null;

        try {

            PreparedStatement stmt = conn.prepareStatement("""
                SELECT *
                FROM orcamento
                WHERE id = ?
            """);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                orcamento = new Orcamento();

                orcamento.setId(rs.getInt("id"));
                orcamento.setDataCriacao(rs.getTimestamp("data_criacao").toLocalDateTime());
                orcamento.setSubtotal(rs.getDouble("subtotal"));
                orcamento.setDesconto(rs.getDouble("desconto"));
                orcamento.setValorTotal(rs.getDouble("valor_total"));
                orcamento.setFormaPagamento(rs.getString("forma_pagamento"));
                orcamento.setStatus(StatusPagamento.valueOf(rs.getString("status")));

                ClienteDAO clienteDAO = new ClienteDAO();
                EventoDAO eventoDAO = new EventoDAO();
                ItemOrcamentoDAO itemDAO = new ItemOrcamentoDAO();

                orcamento.setCliente(clienteDAO.buscarPorId(rs.getInt("cliente_id")));

                orcamento.setEvento(eventoDAO.buscarPorId(rs.getInt("evento_id")));

                orcamento.setItens(itemDAO.listarPorOrcamento(orcamento.getId()));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return orcamento;
    }
    
    private Orcamento getOrcamento(ResultSet rs) throws SQLException {

        Orcamento o = new Orcamento();

        Cliente cliente = new Cliente();
        Evento evento = new Evento();

        cliente.setId(rs.getInt("cliente_id"));
        cliente.setNome(rs.getString("nome_cliente"));
        cliente.setCpfCnpj(rs.getString("cpf_cnpj"));
        cliente.setEndereco(rs.getString("endereco"));

        evento.setId(rs.getInt("evento_id"));
        evento.setNome(rs.getString("nome_evento"));
        evento.setLocalEvento(rs.getString("local_evento"));

        o.setId(rs.getInt("id"));
        o.setCliente(cliente);
        o.setEvento(evento);

        o.setDataCriacao(rs.getTimestamp("data_criacao").toLocalDateTime());
        o.setSubtotal(rs.getDouble("subtotal"));
        o.setDesconto(rs.getDouble("desconto"));
        o.setValorTotal(rs.getDouble("valor_total"));
        o.setFormaPagamento(rs.getString("forma_pagamento"));
        o.setStatus(StatusPagamento.valueOf(rs.getString("status")));

        return o;
    }
    
}
