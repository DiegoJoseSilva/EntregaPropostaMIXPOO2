package Service.ContratoService.Texto;

import Model.ItemOrcamento;
import Model.Orcamento;

public class ItensDaLocacao implements SecaoContrato {
     @Override
    public String gerar(Orcamento o) {

        StringBuilder sb = new StringBuilder();

        sb.append("""
                  3. ITENS DA LOCAÇÃO

                  Conforme orçamento aprovado, integram o presente contrato:

                  """);

        for(ItemOrcamento item : o.getItens()) {

            sb.append("")
              .append(item.getQuantidade())
              .append(" - ")
              .append(item.getItem().getNome())
              .append(" = ")
              .append(item.getSubtotal())
              .append("\n");
        }

        sb.append("\n");

        return sb.toString();
    }
}
