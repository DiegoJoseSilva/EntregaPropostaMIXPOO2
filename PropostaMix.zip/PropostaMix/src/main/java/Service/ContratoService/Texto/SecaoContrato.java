package Service.ContratoService.Texto;

import Model.Orcamento;

public interface SecaoContrato {
    String gerar(Orcamento orcamento);
}

