package Service.ContratoService.Texto;

import Model.Orcamento;


public class FormaPagamento implements SecaoContrato {
    @Override
    public String gerar(Orcamento o) {

       return   """   
                6. FORMA DE PAGAMENTO

                O pagamento será realizado através de %s em até 24 horas antes do evento ou em data acordada entre as partes. 
              
                """
                .formatted(
                    o.getFormaPagamento()
                );
    }
}
