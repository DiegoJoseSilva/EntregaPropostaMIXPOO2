package Service.ContratoService.Texto;

import Model.Orcamento;

public class GerarContrato {

    public String gerarContrato(Orcamento o) {

        StringBuilder contrato = new StringBuilder();

        contrato.append("""
                CONTRATO DE LOCAÇÃO DE SISTEMA DE SOM, ILUMINAÇÃO E ESTRUTURA

                """);

        contrato.append(new IdentificacaoPartes().gerar(o));
        contrato.append(new ObjetoDoContrato().gerar(o));
        contrato.append(new ItensDaLocacao().gerar(o));
        contrato.append(new DataLocalPrazo().gerar(o));
        contrato.append(new ValorContrato().gerar(o));
        contrato.append(new FormaPagamento().gerar(o));
        contrato.append(new ResponsabilidadeLocatario().gerar(o));
        contrato.append(new CancelamentoReagendamento().gerar(o));
        contrato.append(new ForcaMaior().gerar(o));
        contrato.append(new DisposicoesGerais().gerar(o));
        contrato.append(new Finalizacao().gerar(o));

        return contrato.toString();
    }
}
