package Service.ContratoService.Texto;

import Model.Orcamento;
import FactoryContrato.Clausula;
import FactoryContrato.ClausulaFactory;

public class Clausulas implements SecaoContrato {

    @Override
    public String gerar(Orcamento o) {
        
        //mantém um único objeto e apenas anexa (append) novos textos, sendo muito mais eficiente
        StringBuilder sb = new StringBuilder();
        
        //retorna uma lista de clausulas da buscadas na FACTORY
        for(Clausula c : ClausulaFactory.criar(o)) {
            sb.append(c.gerar(o));
            sb.append("\n\n");
        }

        return sb.toString();
    }
}
