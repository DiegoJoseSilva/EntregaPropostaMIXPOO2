package Service.ContratoService.Texto;

import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import java.io.ByteArrayOutputStream;

public class ContratoPDFService {
    
    public byte[] gerarPDF(String contratoTexto) {

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, baos);

            document.open();

            Font fonte = new Font(Font.COURIER, 10);

            Paragraph p = new Paragraph(contratoTexto, fonte);
            document.add(p);

            document.close();

            return baos.toByteArray();

        } catch (Exception e) {
            throw new RuntimeException("Erro ao gerar PDF do contrato", e);
        }
    }
    
}
