package Service.Observer;

import Model.Orcamento;
import java.util.ArrayList;
import java.util.List;

public class OrcamentoNotifier {
    private final List<OrcamentoObserver> observers = new ArrayList<>();

    public OrcamentoNotifier() {

        observers.add(new FluxoCaixaObserver());

    }

    public void notificar(Orcamento orcamento) {

        for (OrcamentoObserver observer : observers) {

            observer.atualizar(orcamento.getId());

        }

    }
}
