package Model;

public enum StatusPagamento {
    PENDENTE,
    PAGO,
    CANCELADO
}
