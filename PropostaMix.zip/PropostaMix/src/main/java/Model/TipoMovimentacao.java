package Model;

public enum TipoMovimentacao {
    RECEITA,
    DESPESA
}
