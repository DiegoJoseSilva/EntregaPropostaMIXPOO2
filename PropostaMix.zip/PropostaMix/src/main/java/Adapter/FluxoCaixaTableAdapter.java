package Adapter;

import Model.FluxoCaixa;

public class FluxoCaixaTableAdapter implements TableAdapter {
   
    private FluxoCaixa fluxo;

    public FluxoCaixaTableAdapter(FluxoCaixa fluxo) {
        this.fluxo = fluxo;
    }

    @Override
    public Object[] toRow() {
        return new Object[]{
            fluxo.getId(),
            fluxo.getNomeEvento(),
            fluxo.getNomeCliente(),
            fluxo.getDataLancamento(),
            fluxo.getValor(),
            fluxo.getTipo()
        };
    }
}
