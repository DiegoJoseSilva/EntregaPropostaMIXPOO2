package Adapter;

import Model.ItemOrcamento;
import Model.Orcamento;

public class ItemOrcamentoTableAdapter implements TableAdapter{
    private ItemOrcamento item;

    public ItemOrcamentoTableAdapter(ItemOrcamento item) {
        this.item = item;
    }

    @Override
    public Object[] toRow() {

        double total = item.getQuantidade() * item.getValorUnitario();

        return new Object[]{
            item.getItem().getId(),
            item.getItem().getNome(),
            item.getQuantidade(),
            item.getValorUnitario(),
            total
        };
    }
}
