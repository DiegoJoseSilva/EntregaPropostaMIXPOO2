package Adapter;

import Model.Evento;

public class EventoTableAdapter implements TableAdapter {
    private Evento e;

    public EventoTableAdapter(Evento evento) {
        this.e = evento;
    }

    @Override
    public Object[] toRow() {
        return new Object[]{
            e.getId(),
            e.getNome(),
            e.getCliente().getNome(),
            e.getDataEvento(),
            e.getLocalEvento()
        };
    }
}
