package controllers;

import DAO.OrcamentoDAO;
import Model.Orcamento;
import java.util.List;

public class OrcamentoController {
    
    OrcamentoDAO oDAO = new OrcamentoDAO();
 
    public boolean atualizar(Orcamento orcamento) {
        return oDAO.atualizar(orcamento);
    }

    public List<Orcamento> listarPorCliente(int idCliente) {
        return oDAO.listarPorCliente(idCliente);
    }
    
    public boolean cancelar(int idOrcamento) {
        return oDAO.cancelar(idOrcamento);
    }
    
    public Orcamento buscarParaContrato(int id){
        return oDAO.buscarParaContrato(id);
    }
}
