package com.mycompany.propostamix;

import View.MenuPrincipal;

public class PropostaMix {

    public static void main(String[] args) {
         java.awt.EventQueue.invokeLater(() -> {
            new MenuPrincipal().setVisible(true);
        });
    }
}
